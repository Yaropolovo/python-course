mock_asset_class.calculate_revenue.return_value = 100500.0
mock_asset_class.build_from_str.return_value.calculate_revenue.return_value = 100500.0




         